const express = require('express');
const app = express();
const bodyParser = require("body-parser");
var mysql = require('mysql');
var routes = require('routes');
var path = require('path');

var con = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'soundsystem1'
});

con.connect()

app.use(express.static('public'));
app.set('view engine', 'ejs')

app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(bodyParser.json());

app.get('/', function (req, res) {
  res.render('index');
})

app.get('/loggedin.ejs', function (req, res) {
  res.render('loggedin');
})

app.get('/services.ejs', function (req, res) {
  con.query('SELECT * FROM packages', function(err, rows, fields) {
    if(err){
      res.redirect('/loggedin.ejs');
    }
    res.render('services', { data: rows });
  });
})

app.get('/services/delete/:id', function (req, res){
  var id = req.params.id;
    con.query('DELETE FROM packages WHERE packageID = ?',[id], function(err,rows){
      if(err){
        console.log("Error deleting : %s ",err);
        res.redirect('/services.ejs');
      }
      con.query('SELECT * FROM packages', function(err, rows, fields) {
      if(err){
        res.redirect('/loggedin.ejs');
      }
      res.render('services', { data: rows });
      });
    })
})

app.post('/services/add', function (req, res){
  var start = 1.00;
  var ids = new Array();
  con.query('SELECT * FROM packages', function(err, rows, fields) {
      if(err){
        res.redirect('/services.ejs');
      }
      for(var i=0; i<rows.length; i++){
        ids.push(rows[i].packageID);
      }
      while(ids.includes(start)){
        start++;      
      }
      var values = [
                [start,req.body.name,req.body.description,req.body.price,req.body.packagetype,null,null,'Approved']
              ];
  con.query('INSERT INTO packages (packageID, name, Description, price, packagetype, spID, packImage, regStatus) VALUES ?', [values], function(err, rows, fields) {
    if(err){
      console.log("Error adding : %s ",err);
      res.redirect('/services.ejs');
    }
    con.query('SELECT * FROM packages', function(err, rows, fields) {
      if(err){
        res.redirect('/loggedin.ejs');
      }
      res.render('services', { data: rows });
    });
  });
  });
  
})

app.get('/transactions.ejs', function (req, res) {
  con.query('SELECT transactions.TransactionID, accounts.name AS aName, packages.name AS pName, packages.Description AS "pDesc", transactions.Date, transactions.Status FROM transactions INNER JOIN accounts ON transactions.AccID = accounts.accID INNER JOIN packages ON transactions.PackID = packages.packageID', function(err, rows, fields) {
    if(err){
      res.redirect('/loggedin.ejs');
    }
    res.render('transactions', { data: rows });
  });
})

app.get('/transactions/cancel/:id', function (req, res){
  var id = req.params.id;
    con.query('UPDATE transactions SET Status = "Cancelled" WHERE TransactionID = ?',[id], function(err,rows){
      if(err){
        console.log("Error cancelling : %s ",err);
        res.redirect('/transactions.ejs');
      }
      con.query('SELECT transactions.TransactionID, accounts.name AS aName, packages.name AS pName, packages.Description AS pDesc, transactions.Date, transactions.Status FROM transactions INNER JOIN accounts ON transactions.AccID = accounts.accID INNER JOIN packages ON transactions.PackID = packages.packageID', function(err, rows, fields) {
      if(err){
        res.redirect('/loggedin.ejs');
      }
      res.render('transactions', { data: rows });
      });
    })
})

app.get('/transactions/inprogress/:id', function (req, res){
  var id = req.params.id;
    con.query('UPDATE transactions SET Status = "In Progress" WHERE TransactionID = ?',[id], function(err,rows){
      if(err){
        console.log("Error updating : %s ",err);
        res.redirect('/transactions.ejs');
      }
      con.query('SELECT transactions.TransactionID, accounts.name AS aName, packages.name AS pName, packages.Description AS "pDesc", transactions.Date, transactions.Status FROM transactions INNER JOIN accounts ON transactions.AccID = accounts.accID INNER JOIN packages ON transactions.PackID = packages.packageID', function(err, rows, fields) {
      if(err){
        res.redirect('/loggedin.ejs');
      }
      res.render('transactions', { data: rows });
      });
    })
})

app.get('/transactions/done/:id', function (req, res){
  var id = req.params.id;
    con.query('UPDATE transactions SET Status = "Returned" WHERE TransactionID = ?',[id], function(err,rows){
      if(err){
        console.log("Error returning : %s ",err);
        res.redirect('/transactions.ejs');
      }
      con.query('SELECT transactions.TransactionID, accounts.name AS aName, packages.name AS pName, packages.Description AS "pDesc", transactions.Date, transactions.Status FROM transactions INNER JOIN accounts ON transactions.AccID = accounts.accID INNER JOIN packages ON transactions.PackID = packages.packageID', function(err, rows, fields) {
      if(err){
        res.redirect('/loggedin.ejs');
      }
      res.render('transactions', { data: rows });
      });
    })
})

app.listen(3000, function () {
  console.log('Listening on port 3000!')
})
