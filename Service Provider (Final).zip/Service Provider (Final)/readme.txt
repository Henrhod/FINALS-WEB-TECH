Service Provider Module Setup:
1. Go to the "Service Provider Module" folder.
2. Click on the path on top, type "cmd", then press enter.
3. Type "node server.js" and then press enter.
4. Open a browser and go to "[ipaddress]:3000" or "[domainname.com]:3000".