-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: database
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `packageID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `price` double NOT NULL,
  `status` enum('not available','available') NOT NULL,
  `spID` int(11) NOT NULL,
  `packImage` longblob NOT NULL,
  PRIMARY KEY (`packageID`),
  UNIQUE KEY `packageID_UNIQUE` (`packageID`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `spID_idx` (`spID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Package A from Bose','3x large Speakers, 6x small Speaker, 4x mics with stand and 1x Equalizer',5000,'not available',1,''),(2,'Package B from Bose','4x Speaker with 2x Stands, 4x mic, 4x Speaker to Equalizer and 4x Mic to equalizer cords and 1 Equalizer',3000,'not available',2,''),(3,'Mic Package','4x Large Speakers, 6x Small Speakers, 10x mics with 6x stands, 1x Equalizer and cords',4999,'available',3,''),(4,'KEF Q550 Floor-Standing speaker','2x Speakers with stands, 2x mics with stands, 1 reciever, 2 cords, 1 Equalizer and 2 Bags',10000,'available',1,''),(5,'Mini Concert','2x Small Speakers, 2x small lights, 1x projector with screen, 3x Equalizers',25000,'available',1,'');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-13 22:23:41
