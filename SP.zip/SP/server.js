const express = require('express');
//const bodyParser = require('body-parser');
//const request = require('request');
const app = express();
var mysql = require('mysql');
var routes = require('routes');
var path = require('path');

//var services = require('./routes/services');

var con = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'soundsystem'
});

con.connect()

app.use(express.static('public'));
app.set('view engine', 'ejs')

app.get('/', function (req, res) {
  res.render('index');
})

app.get('/loggedin.ejs', function (req, res) {
  res.render('loggedin');
})

app.get('/reservations.ejs', function (req, res) {
  con.query('SELECT * FROM reservations', function(err, rows, fields) {
    if(err){
      res.redirect('/loggedin.ejs');
    }
    res.render('reservations', { data: rows });
  });
})

app.get('/services.ejs', function (req, res) {
  con.query('SELECT * FROM packages', function(err, rows, fields) {
    if(err){
      res.redirect('/loggedin.ejs');
    }
    res.render('services', { data: rows });
  });
})

app.get('/services/delete/:id', function (req, res){
  var id = req.params_id;
    con.query('DELETE FROM packages WHERE packageID = ?',[id], function(err,rows){
      if(err){
        console.log("Error deleting : %s ",err);
        res.redirect('/services.ejs');
      }
      //res.render('services', { data: rows });
    })
})

app.get('/transactions.ejs', function (req, res) {
  con.query('SELECT * FROM transactions', function(err, rows, fields) {
    if(err){
      res.redirect('/loggedin.ejs');
    }
    res.render('transactions', { data: rows });
  });
})

app.listen(3000, function () {
  console.log('Listening on port 3000!')
})
