var mysql = require('mysql');
var http = require('http');
var fs = require('fs');

var product;

var con = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'soundsystem'
});

con.connect(function(err) {
  if (err) throw err;
  con.query(`SELECT * FROM item`, function (err, result, fields) {
    if (err) throw err;
    item = result;
  });
  con.query(`SELECT * FROM packages`, function (err, result, fields) {
    if (err) throw err;
    packs = result;
  });
  con.query(`SELECT * FROM transactions`, function (err, result, fields) {
    if (err) throw err;
    trans = result;
  });
});

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'}); 
  fs.readFile('./index.html', null, function(error, data) {
    if(error) throw error;
    res.write(data);
    
    if(req.url == "/items") {
      res.write('<table border = 1px>');
      res.write('<thead>');
      res.write('<tr>');
      res.write('<th> Item ID </th>');
      res.write('<th> Item Name </th>');
      res.write('<th> Quantity </th>');
      res.write('<th> Belongs To </th>');
      //res.write('<th> Image Path </th>');
      res.write('</tr>');
      res.write('</thead>');
      res.write('<tbody>');
      for(var i = 0; i < item.length; i++){
        res.write('<tr>');
        res.write('<td>' + item[i].itemID+ '</td>');
        res.write('<td>' + item[i].itemname + '</td>');
        res.write('<td>' + item[i].qty + '</td>');
        res.write('<td>' + item[i].belongsTo + '</td>');
        //res.write('<td>' + item[i].imagePath + '</td>');
        res.write('</tr>');
      }
      res.write('</tbody>');
      res.write('</table>');
    }

    if(req.url == "/packages") {
      res.write('<table border = 1px>');
      res.write('<thead>');
      res.write('<tr>');
      res.write('<th> Package ID </th>');
      res.write('<th> Package Name </th>');
      res.write('<th> Price </th>');
      res.write('<th> Status </th>');
      res.write('</tr>');
      res.write('</thead>');
      res.write('<tbody>');
      for(var i = 0; i < packs.length; i++){
        res.write('<tr>');
        res.write('<td>' + packs[i].packageID + '</td>');
        res.write('<td>' + packs[i].name + '</td>');
        res.write('<td>' + packs[i].price + '</td>');
        res.write('<td>' + packs[i].status + '</td>');
        res.write('</tr>');
      }
      res.write('</tbody>');
      res.write('</table>');
    }

    if(req.url == "/transactions") {
      res.write('<table border = 1px>');
      res.write('<thead>');
      res.write('<tr>');
      res.write('<th> Transaction ID </th>');
      res.write('<th> Customer ID </th>');
      res.write('<th> Package ID </th>');
      res.write('<th> Status </th>');
      res.write('<th> Transaction Date </th>');
      res.write('</tr>');
      res.write('</thead>');
      res.write('<tbody>');
      for(var i = 0; i < trans.length; i++){
        res.write('<tr>');
        res.write('<td>' + trans[i].transID + '</td>');
        res.write('<td>' + trans[i].prodname + '</td>');
        res.write('<td>' + trans[i].price + '</td>');
        res.write('</tr>');
      }
      res.write('</tbody>');
      res.write('</table>');
    }

    res.end();
  });
}).listen(8080);